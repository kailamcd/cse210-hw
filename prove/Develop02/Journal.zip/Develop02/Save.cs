public class Save
{
    public string _saveDate = "";
    public string _savePrompt = "";
    public string _saveEntry = "";
    public string _fileName = "";

    public Save()
    {
    }



    // public void AddToFile()
    // {
    //     StreamWriter sw = new StreamWriter
    // }

    // public void CreateJournalForFile(string _fileName)
    // {
    //     foreach (Entry entry in _entries)
    //     {
    //         var allEntries = string.Join("/n", _entries);
    //         System.IO.File.WriteAllText(@$"{_fileName}", allEntries);
    //     }
    // }

}